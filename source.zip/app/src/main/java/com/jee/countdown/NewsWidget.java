package com.jee.countdown;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

public class NewsWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        Updater.render(ctx);
        Updater.poke(ctx);
    }

    @Override
    public void onEnabled(Context ctx) {
        Updater.schedule(ctx);
    }

    @Override
    public void onDisabled(Context ctx) {
        Updater.cancelIfUnused(ctx);
    }
}
