package com.jee.countdown;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean ticking = false;
    private TextView title, sub, msg;
    private TextView[] nums;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!ticking) return;
            bind();
            long now = System.currentTimeMillis();
            h.postDelayed(this, 1000 - (now % 1000) + 5);
        }
    };

    private final Runnable hideMsg = () -> msg.setText("");

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        title = findViewById(R.id.a_title);
        sub = findViewById(R.id.a_sub);
        msg = findViewById(R.id.a_msg);
        nums = new TextView[]{
                findViewById(R.id.a_y), findViewById(R.id.a_d), findViewById(R.id.a_h),
                findViewById(R.id.a_m), findViewById(R.id.a_s)};

        TextView plus = findViewById(R.id.a_plus);
        plus.setOnClickListener(v -> {
            plus.animate().rotationBy(90f).setDuration(200).start();
            msg.setText("padhle B**K");
            Toast.makeText(this, "padhle B**K", Toast.LENGTH_SHORT).show();
            h.removeCallbacks(hideMsg);
            h.postDelayed(hideMsg, 3000);
        });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Updater.schedule(this);
        Updater.startLive(this);   // keeps widget seconds running too
        Updater.pokeForce(this);   // fetch the latest date and news
        ticking = true;
        h.post(tick);
    }

    @Override
    protected void onPause() {
        ticking = false;
        h.removeCallbacks(tick);
        super.onPause();
    }

    private void bind() {
        long[] v = Updater.parts(this);
        boolean leadingZero = true;
        for (int i = 0; i < 5; i++) {
            if (v[i] != 0) leadingZero = false;
            nums[i].setText(v[i] < 10 ? "0" + v[i] : String.valueOf(v[i]));
            nums[i].setTextColor(leadingZero && i < 4 ? 0xFFE10600 : 0xFFFFFFFF);
        }
        title.setText(Updater.title(this));
        sub.setText(Updater.subtitle(this));
    }
}
