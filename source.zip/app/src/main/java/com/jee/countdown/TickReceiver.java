package com.jee.countdown;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

/** Runs every minute: redraws the widgets and fetches fresh data when it is due. */
public class TickReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context ctx, Intent intent) {
        final String action = intent.getAction();

        if (Updater.ACTION_PLUS.equals(action)) {
            final Context app = ctx.getApplicationContext();
            new Handler(Looper.getMainLooper()).post(() ->
                    Toast.makeText(app, "padhle bhai", Toast.LENGTH_SHORT).show());
            Updater.flash(ctx);
            final PendingResult pr = goAsync();
            new Thread(() -> {
                try {
                    Thread.sleep(3000);
                    Updater.render(ctx);
                } catch (Exception ignored) {
                } finally {
                    pr.finish();
                }
            }).start();
            return;
        }

        Updater.startLive(ctx); // no-op if already running; restarts it after the process was killed
        final boolean force = Updater.ACTION_FORCE.equals(action);
        if (force || Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            Updater.startLive(ctx); // tapping a widget (or boot) turns on per-second updates
        }
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                Updater.refresh(ctx, force);
            } catch (Exception ignored) {
            } finally {
                Updater.schedule(ctx);
                pr.finish();
            }
        }).start();
    }
}
