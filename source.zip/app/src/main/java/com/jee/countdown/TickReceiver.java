package com.jee.countdown;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Runs every minute: redraws the widgets and fetches fresh data when it is due. */
public class TickReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context ctx, Intent intent) {
        final boolean force = Updater.ACTION_FORCE.equals(intent.getAction());
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                Updater.refresh(ctx, force);
            } catch (Exception ignored) {
            } finally {
                Updater.schedule(ctx);
                pr.finish();
            }
        }).start();
    }
}
