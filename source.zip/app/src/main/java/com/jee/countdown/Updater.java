package com.jee.countdown;

import android.animation.ArgbEvaluator;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Xml;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

final class Updater {
    static final String ACTION_TICK = "com.jee.countdown.TICK";
    static final String ACTION_FORCE = "com.jee.countdown.FORCE";

    // Built-in fallback, used until the date has been fetched from the internet.
    private static final long FALLBACK_EPOCH =
            ZonedDateTime.of(2027, 1, 20, 9, 0, 0, 0, ZoneId.of("Asia/Kolkata")).toEpochSecond();
    private static final String FALLBACK_TITLE = "JEE MAINS 2027";

    private static final String NEWS_URL =
            "https://news.google.com/rss/search?q=JEE+Main+OR+JEE+Advanced+OR+JoSAA"
                    + "+OR+IIT+JEE+OR+NTA+JEE+when:7d&hl=en-IN&gl=IN&ceid=IN:en";

    private static final long DATE_OK_MS = 6L * 3600_000L;
    private static final long DATE_RETRY_MS = 15L * 60_000L;
    private static final long NEWS_OK_MS = 30L * 60_000L;
    private static final long NEWS_RETRY_MS = 10L * 60_000L;

    private static final double[] STOP_DAYS = {100, 80, 60, 40, 20, 10, 5, 0};
    private static final int[] STOP_COLORS = {
            0xFF1B8A5A, // 100+ days  green
            0xFF7CB342, // 80         lime
            0xFFF9A825, // 60         amber
            0xFFFB8C00, // 40         orange
            0xFFF4511E, // 20         deep orange
            0xFFE53935, // 10         red
            0xFFC62828, // 5          crimson
            0xFF8E0000  // 0          dark red
    };

    // Shown in the last 7 days (changes every 3 hours)
    private static final String[] CALM_QUOTES = {
            "Breathe. You've already done the work.",
            "Calm mind, sharp mind.",
            "One question at a time. That's all.",
            "Sleep well. Rest is part of revision.",
            "You are more prepared than you feel.",
            "Trust your preparation.",
            "Stay relaxed. Marks follow focus.",
            "Do your best, then let it go.",
            "Take a walk. Drink water. Smile.",
            "This exam is one step, not your whole story.",
            "Slow is smooth, smooth is fast.",
            "Be proud of how far you've come."
    };

    private Updater() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("jee", Context.MODE_PRIVATE);
    }

    // ---------------------------------------------------------------- scheduling

    private static PendingIntent tickPi(Context c) {
        Intent i = new Intent(c, TickReceiver.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent forcePi(Context c) {
        Intent i = new Intent(c, TickReceiver.class).setAction(ACTION_FORCE);
        return PendingIntent.getBroadcast(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        long now = System.currentTimeMillis();
        long next = now - (now % 60000L) + 60000L;
        am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickPi(c));
    }

    static void cancelIfUnused(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int n = m.getAppWidgetIds(new ComponentName(c, JeeWidget.class)).length
                + m.getAppWidgetIds(new ComponentName(c, NewsWidget.class)).length;
        if (n == 0) {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(tickPi(c));
        }
    }

    /** Ask TickReceiver (which can use a background thread) to refresh now. */
    static void poke(Context c) {
        c.sendBroadcast(new Intent(c, TickReceiver.class).setAction(ACTION_TICK));
    }

    // ---------------------------------------------------------------- refresh

    static void refresh(Context c, boolean force) {
        render(c);
        SharedPreferences sp = prefs(c);
        long now = System.currentTimeMillis();
        boolean changed = false;
        if (force || now >= sp.getLong("date_next", 0)) changed |= fetchDate(c);
        if (force || now >= sp.getLong("news_next", 0)) changed |= fetchNews(c);
        if (changed) render(c);
    }

    static void render(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        SharedPreferences sp = prefs(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, JeeWidget.class)))
            m.updateAppWidget(id, countdown(c, sp));
        for (int id : m.getAppWidgetIds(new ComponentName(c, NewsWidget.class)))
            m.updateAppWidget(id, news(c, sp));
    }

    // ---------------------------------------------------------------- network

    private static String httpGet(String url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(5000);
        con.setReadTimeout(5000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) JEECountdown");
        try {
            if (con.getResponseCode() != 200) throw new IOException("HTTP " + con.getResponseCode());
            try (InputStream in = con.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total > 2_000_000) break;
                }
                return out.toString("UTF-8");
            }
        } finally {
            con.disconnect();
        }
    }

    private static boolean fetchDate(Context c) {
        SharedPreferences sp = prefs(c);
        long now = System.currentTimeMillis();
        try {
            JSONObject o = new JSONObject(httpGet(c.getString(R.string.config_url)));
            long epoch = OffsetDateTime.parse(o.getString("date")).toEpochSecond();
            sp.edit().putLong("exam_epoch", epoch)
                    .putString("exam_name", o.optString("name", FALLBACK_TITLE))
                    .putLong("date_next", now + DATE_OK_MS).apply();
            return true;
        } catch (Exception e) {
            sp.edit().putLong("date_next", now + DATE_RETRY_MS).apply();
            return false;
        }
    }

    private static boolean fetchNews(Context c) {
        SharedPreferences sp = prefs(c);
        long now = System.currentTimeMillis();
        try {
            String xml = httpGet(NEWS_URL);
            XmlPullParser p = Xml.newPullParser();
            p.setInput(new StringReader(xml));
            JSONArray arr = new JSONArray();
            boolean inItem = false;
            String title = null, link = null, date = null;
            int ev = p.getEventType();
            while (ev != XmlPullParser.END_DOCUMENT && arr.length() < 6) {
                if (ev == XmlPullParser.START_TAG) {
                    String n = p.getName();
                    if ("item".equals(n)) {
                        inItem = true;
                        title = null; link = null; date = null;
                    } else if (inItem) {
                        if ("title".equals(n)) title = p.nextText();
                        else if ("link".equals(n)) link = p.nextText();
                        else if ("pubDate".equals(n)) date = p.nextText();
                    }
                } else if (ev == XmlPullParser.END_TAG && "item".equals(p.getName())) {
                    inItem = false;
                    if (title != null && link != null) {
                        String src = "";
                        int i = title.lastIndexOf(" - ");
                        if (i > 0) {
                            src = title.substring(i + 3);
                            title = title.substring(0, i);
                        }
                        long t = now;
                        try {
                            t = ZonedDateTime.parse(date, DateTimeFormatter.RFC_1123_DATE_TIME)
                                    .toInstant().toEpochMilli();
                        } catch (Exception ignored) {}
                        JSONObject o = new JSONObject();
                        o.put("h", title.trim());
                        o.put("s", src);
                        o.put("l", link.trim());
                        o.put("t", t);
                        arr.put(o);
                    }
                }
                ev = p.next();
            }
            if (arr.length() == 0) throw new IOException("no items");
            sp.edit().putString("news", arr.toString()).putLong("news_at", now)
                    .putLong("news_next", now + NEWS_OK_MS).apply();
            return true;
        } catch (Exception e) {
            sp.edit().putLong("news_next", now + NEWS_RETRY_MS).apply();
            return false;
        }
    }

    // ---------------------------------------------------------------- countdown view

    private static RemoteViews countdown(Context c, SharedPreferences sp) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_jee);

        long exam = sp.getLong("exam_epoch", FALLBACK_EPOCH);
        String name = sp.getString("exam_name", FALLBACK_TITLE);

        long secs = exam - System.currentTimeMillis() / 1000L;
        boolean over = secs <= 0;
        if (over) secs = 0;

        long totalDays = secs / 86400L;
        long years = totalDays / 365L;
        long days = totalDays % 365L;
        long hours = (secs % 86400L) / 3600L;
        long mins = (secs % 3600L) / 60L;
        double daysLeft = secs / 86400.0;

        rv.setTextViewText(R.id.title, name);
        rv.setTextViewText(R.id.num, two(years) + ":" + two(days) + ":" + two(hours) + ":" + two(mins));
        rv.setTextViewText(R.id.subtitle, over ? "Exam time. All the best!" : message(daysLeft));
        rv.setInt(R.id.bg, "setColorFilter", colorFor(daysLeft));
        rv.setOnClickPendingIntent(R.id.root, forcePi(c));
        return rv;
    }

    private static String message(double d) {
        if (d > 100) return "Plenty of time. Build the habit.";
        if (d > 60) return "Stay consistent. Finish the syllabus.";
        if (d > 20) return "Revision mode. Mock tests daily.";
        if (d > 7) return "Final stretch. Stay calm, stay sharp.";
        if (d <= 1) return "Light revision, early sleep. You've got this!";
        int i = (int) ((System.currentTimeMillis() / (3L * 3600_000L)) % CALM_QUOTES.length);
        return CALM_QUOTES[i];
    }

    private static String two(long v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static int colorFor(double days) {
        if (days >= STOP_DAYS[0]) return STOP_COLORS[0];
        ArgbEvaluator ev = new ArgbEvaluator();
        for (int i = 0; i < STOP_DAYS.length - 1; i++) {
            if (days >= STOP_DAYS[i + 1]) {
                float t = (float) ((STOP_DAYS[i] - days) / (STOP_DAYS[i] - STOP_DAYS[i + 1]));
                return (int) ev.evaluate(t, STOP_COLORS[i], STOP_COLORS[i + 1]);
            }
        }
        return STOP_COLORS[STOP_COLORS.length - 1];
    }

    // ---------------------------------------------------------------- news view

    private static final int[] ROW = {R.id.r0, R.id.r1, R.id.r2, R.id.r3};
    private static final int[] ROW_T = {R.id.r0_t, R.id.r1_t, R.id.r2_t, R.id.r3_t};
    private static final int[] ROW_M = {R.id.r0_m, R.id.r1_m, R.id.r2_m, R.id.r3_m};

    private static RemoteViews news(Context c, SharedPreferences sp) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_news);
        rv.setOnClickPendingIntent(R.id.news_header, forcePi(c));

        long at = sp.getLong("news_at", 0);
        rv.setTextViewText(R.id.news_updated, at == 0 ? "" : "Updated " +
                DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
                        .format(Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault())));

        JSONArray arr;
        try {
            arr = new JSONArray(sp.getString("news", "[]"));
        } catch (JSONException e) {
            arr = new JSONArray();
        }

        for (int i = 0; i < 4; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null) {
                rv.setViewVisibility(ROW[i], View.VISIBLE);
                rv.setTextViewText(ROW_T[i], o.optString("h"));
                String meta = o.optString("s");
                String ago = ago(o.optLong("t"));
                rv.setTextViewText(ROW_M[i], meta.isEmpty() ? ago : meta + " · " + ago);
                Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(o.optString("l")))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                rv.setOnClickPendingIntent(ROW[i], PendingIntent.getActivity(c, 100 + i, it,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            } else if (i == 0) {
                rv.setViewVisibility(ROW[0], View.VISIBLE);
                rv.setTextViewText(ROW_T[0], "Fetching latest JEE updates. Tap the header to refresh.");
                rv.setTextViewText(ROW_M[0], "Needs internet");
            } else {
                rv.setViewVisibility(ROW[i], View.GONE);
            }
        }
        return rv;
    }

    private static String ago(long t) {
        long m = Math.max(0, (System.currentTimeMillis() - t) / 60000L);
        if (m < 60) return m + "m ago";
        if (m < 1440) return (m / 60) + "h ago";
        return (m / 1440) + "d ago";
    }
}
